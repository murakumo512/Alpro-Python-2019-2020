Soal 1. Tulis manual mba gan
Soal 2. Konversikan yah
Soal 3. pake 11.txt sama 12.txt ya mba gan